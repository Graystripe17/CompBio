------------------
Usage Instructions
------------------
Describe how to run your program.
1) python3 dt.py
2) The output prints out relevant statistics and decision tree as well as individual classifications on the test data
