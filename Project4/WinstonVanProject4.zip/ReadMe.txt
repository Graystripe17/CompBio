------------------
Usage Instructions
------------------
Describe how to run your program.
1) Keep the directory structure of the zip file
2) python3 lr.py
3) Wait for 30s
