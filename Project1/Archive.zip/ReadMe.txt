------------------
Usage Instructions
------------------
1) Note that blosum.txt must be in the same directory
2) Using python version 3.6.5, execute `python3 align.py`
3) Enter either N or S
4) Choose either 1-4

