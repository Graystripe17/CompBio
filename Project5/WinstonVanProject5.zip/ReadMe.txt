------------------
Usage Instructions
------------------
Describe how to run your program.

python3 p5.py

The eb.pickle and hec.pickle must be present in the current directory
fasta, pssm, and tmalign directories must be the same as well