------------------
Usage Instructions
------------------
1. python3 gnb.py
2. Place appropriate files in fasta/ ss/ and pssm/
3. The algorithm will randomly train and test for 60%
